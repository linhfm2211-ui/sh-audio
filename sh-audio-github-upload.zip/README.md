# SH Audio Crawler

Crawler metadata YouTube playlist cho SH Audio. Script nay chi lay metadata bang `yt-dlp`, khong download audio/video.

## Cai dependencies

```bash
python -m pip install -r crawler/requirements.txt
```

## Chay dry-run

```bash
python crawler/crawl_playlist.py "https://www.youtube.com/playlist?list=PLAYLIST_ID" --dry-run --limit 5
```

Dry-run se in JSON gom `source`, `story`, `chapters`, khong ghi Supabase.

## Ghi vao Supabase

Can bien moi truong:

```text
NEXT_PUBLIC_SUPABASE_URL=https://xzzlrmlapawecahoavqn.supabase.co
SUPABASE_SERVICE_ROLE_KEY=...
```

Sau do chay:

```bash
python crawler/crawl_playlist.py "https://www.youtube.com/playlist?list=PLAYLIST_ID"
```

Khong dat `SUPABASE_SERVICE_ROLE_KEY` vao frontend, `.env.local` public, hoac bien `NEXT_PUBLIC_*`.
